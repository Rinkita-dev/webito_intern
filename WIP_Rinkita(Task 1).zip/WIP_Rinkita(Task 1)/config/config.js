const config = {
    secret_jwt : "thisismysecretkey",
    emailUser:'rinktamistry@gmail.com',
    emailPassword: 'yrru uugj rbub rvuk' //app password
}

module.exports = config;