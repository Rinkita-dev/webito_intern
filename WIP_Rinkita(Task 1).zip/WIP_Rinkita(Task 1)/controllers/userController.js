const User = require("../models/userModel");
const bcryptjs = require("bcryptjs");
const config = require("../config/config");
const jwt = require("jsonwebtoken");

const nodemailer = require("nodemailer");
const randomstring = require("randomstring");
//const { response } = require("../routes/userRoute");

const sendresetPasswordMail = async(name, email, token)=>{
    try {

        const transporter = nodemailer.createTransport({
            service:'gmail',
            port:465,
            secure: true,
            auth:{
                user:config.emailUser,
                pass:config.emailPassword
            }
        });

        const mailOptions = {
            from:config.emailUser,
            to:email,
            subject:'For Reset Password',
            html:'<p> Hii ' + name + ', Please copy the link and <a href="http://localhost:3000/api/reset-password?token="'+token+'"></a> reset your password'
        }
        transporter.sendMail(mailOptions, (error,info) => {
            if(error){
                console.log(error);
            }
            else{
                console.log("Mail has been sent:- ", info.response);
            }
        });
        
    } catch (error) {
        res.status(400).send({success: false,msg: error.message});
    }

}

const create_token = async(id)=>{
    try {

        const token = await jwt.sign({_id: id}, config.secret_jwt);
        return token;
        
    } catch (error) {
        res.status(400).send(error.message);
    }
}

const securePassword = async (password) => {
    try {
        const passwordHash = await bcryptjs.hash(password, 10);
        return passwordHash;
    } catch (error) {
        throw error; // Throw the error to propagate it to the caller
    }
};

const register_user = async (req, res) => {
    try {
        const spassword = await securePassword(req.body.password);
        const user = new User({
            name: req.body.name,
            email: req.body.email,
            username: req.body.username,
            password: spassword,
            contact: req.body.contact,
            dob: req.body.dob,
            gender: req.body.gender,
            city: req.body.city,
            country: req.body.country,
            position: req.body.position
        });

        const userData = await User.findOne({ email: req.body.email });
        if (userData) {
            res.status(200).send({ success: false, msg: "This email is already exists." });
        } else {
            const user_data = await user.save();
            res.status(200).send({ success: true, data: user_data });
        }

    } catch (error) {
        console.error(error); // Log the error for debugging purposes
        res.status(400).send(error.message); // Send error message as response
    }
};

//Login Method

const user_login = async(req , res)=>{
    try {
        
        const email = req.body.email;
        const passwword = req.body.password;

        const userData = await User.findOne({ email: email });
        if (userData) {
            const passwordMatch = await bcryptjs.compare(passwword,userData.password);
            if (passwordMatch) {
                const tokenData = await create_token(userData._id);
                const userResult = {
                    _id : userData._id,
                    name : userData.name,
                    email : userData.email,
                    username: userData.username,
                    password : userData.password,
                    contact: userData.contact,
                    dob: userData.dob,
                    gender: userData.gender,
                    city: userData.city,
                    country: userData.country,
                    position: userData.position,
                    toke: tokenData
                }

                res.status(200).send({
                    success: true,
                    msg: "User details",
                    data: userResult
                });
            }
            else{
                res.status(200).send({ success: false, msg: "Login Details Are Incorrect." });
            }
        } 
        else {
            res.status(200).send({ success: false, msg: "Login Details Are Incorrect." });
        }

    } catch (error) {
        res.status(400).send(error.message);
    }
}


//update password method

const update_password = async(req, res)=>{
    try {
        const user_id = req.body.user_id;
        const password = req.body.password;

        const data = await User.findOne({_id: user_id});

        if (data) {
            const newpassword = await securePassword(password);

           const userData = await User.findByIdAndUpdate({_id:user_id},{$set:{
                password: newpassword
            }});

            res.status(200).send({success:true,msg:"Your Password has been updated."})

        } else {
            res.status(200).send({success:false,msg: "User Id Not Found!"});
        }

    } catch (error) {
        res.status(400).send(error.message);
    }
}

const forget_password = async(req,res)=>{
    try {

        const email = req.body.email;
        const userData = await User.findOne({email:email});
        if (userData) {

            const randomString = randomstring.generate();
            const data = await User.updateOne({email:email},{$set:{token:randomString}});
            sendresetPasswordMail(userData.name,userData.email,randomString);
            res.status(200).send({success:true,msg:"Please Check Your Inbox of Mail and Reset Your Password."});
            
        }
        else{
            res.status(200).send({success:true,msg:"This email dose not exist."});
        }
        
    } catch (error) {
        res.status(400).send({success:false,msg:error.message});
    }
} 

module.exports = {
    register_user,
    user_login,
    update_password,
    forget_password
};
